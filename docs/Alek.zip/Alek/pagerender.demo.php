<?php 

include("express/Router.php");

$app = new Router ("");

$app->get('/', function ($req, $res) {
      $res->render('homepage', [
            "title" => "Zor",
            "data" => ["name" => "Uzbekistan Airways"]
      ]);
      
      return $res->end();
});

?>