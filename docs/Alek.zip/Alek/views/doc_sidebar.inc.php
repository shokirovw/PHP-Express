<div class="uk-section">
  <div class="uk-container">
    <div class="uk-grid-large" data-uk-grid>

<div class="sidebar-fixed-width uk-visible@m">
        <div class="sidebar-docs uk-position-fixed uk-margin-top">
          <?php foreach ($data['tabs'] as $group => $tabs) { ?>
            <h5><?=$group?></h5>
            <ul class="uk-nav uk-nav-default doc-nav">
              <?php foreach ($tabs as $tab) { ?>
                  <li><a href="<?=$dir?>/doc/<?=$tab['id']?>"><?=$tab['title']?></a></li>
              <?php } ?>
            </ul>
          <?php } ?>
        </div>
</div>