<div class="uk-section">
  <div class="uk-container uk-container-xsmall">
    <article class="uk-article">
      <h1 class="uk-article-title">Got Any Questions?</h1>
      <?php if (isset($data['error']) && !empty($data['error'])) { ?>
        <p><span class="uk-label" style="background-color: #ff4772"><?=$data['error']?></span></p>
      <?php } ?>
      <?php if (isset($data['error']) && !empty($data['message'])) { ?>
        <p><span class="uk-label" style="background-color: #3778ff"><?=$data['message']?></span></p>
      <?php } ?>
      <div class="article-content link-primary">
        <h5 id="morbi-varius-in-accumsan-blandit-elit-ligula-velit-luctus-mattis-ante-nulla-nulla">Fastly contact service. Powered by Alek</h5>
        <p>We are constantly shipping some quality-of-life improvements to Fastly with every new update, feel free to ask any questions you have got</p>
        <form class="uk-form-stacked uk-margin-medium-top" method="POST" action="<?=$dir?>/receiveContact"
          accept-charset="UTF-8">
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="name">Name</label>
            <div class="uk-form-controls">
              <input id="name" class="uk-input uk-form-large uk-border-rounded" name="name" type="text" required="">
            </div>
          </div>
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="_replyto">Email</label>
            <div class="uk-form-controls">
              <input id="_replyto" class="uk-input uk-form-large uk-border-rounded" name="_replyto" type="email" required="">
            </div>
          </div>
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="_subject">Subject</label>
            <div class="uk-form-controls">
              <input id="_subject" class="uk-input uk-form-large uk-border-rounded" name="_subject" type="text">
            </div>
          </div>
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="message">Message</label>
            <div class="uk-form-controls">
              <textarea id="message" class="uk-textarea uk-form-large uk-border-rounded" name="message" rows="5" minlength="10"
                required=""></textarea>
            </div>
          </div>
          <div>
            <input class="uk-button uk-button-primary uk-button-large uk-width-1-1" type="submit" value="Send">
          </div>
        </form>
      </div>
    </article>
  </div>
</div>