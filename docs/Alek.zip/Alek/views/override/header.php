<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=$title?></title>
    <link rel="shortcut icon" type="image/png" href="https://via.placeholder.com/20.png" >
    <link href="https://fonts.googleapis.com/css?family=Heebo:300,400" rel="stylesheet">
    <link rel="stylesheet" href="<?=$dir?>/views/css/main.css" />
    <script src="<?=$dir?>/views/js/uikit.js"></script>
</head>

<body>

<div data-uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent; top: 200">
  <nav class="uk-navbar-container">
    <div class="uk-container">
      <div data-uk-navbar>
        <div class="uk-navbar-left">
          <a class="uk-navbar-item uk-logo uk-visible@m" href="<?=$dir?>/">Fastly</a>
          <ul class="uk-navbar-nav uk-visible@m">
            <li><a href="<?=$dir?>/">Home</a></li>
            <li ><a href="<?=$dir?>/doc/1">Docs</a></li>
            <li><a href="<?=$dir?>/articles">Blog</a></li>
            <li><a href="<?=$dir?>/changelog">Changelogs</a></li>
          </ul>
        </div>
        <div class="uk-navbar-right">
          <ul class="uk-navbar-nav uk-visible@m">
            <li>
              <div class="uk-navbar-item">
                <a class="uk-button uk-button-success" href="<?=$dir?>/contact">Contact</a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
</div>