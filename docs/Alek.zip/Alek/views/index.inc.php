
	<div class="uk-section section-hero uk-position-relative" data-uk-scrollspy="cls: uk-animation-slide-bottom-medium; repeat: true">
		<div class="uk-container uk-container-small">
			<h1 style="font-size: 90px; padding-top: 30px;" class="uk-heading-medium uk-text-center uk-margin-remove-top">The PHP framework for the Web</h1>
			<p class="uk-text-lead uk-text-center">New and fresh Fastly enables you to create full-stack web applications by extending the latest PHP features, and integrating powerful Express structure for the fastest development.</p>
			<div class="hero-search">
				<div class="uk-position-relative uk-text-center">
					<a style="padding-left: 40px; padding-right: 40px; margin-right: 6px; margin-left: 6px;" class="uk-button uk-button-success" href="<?=$dir?>/changelog">Changelogs</a>
					<a style="padding-left: 40px; padding-right: 40px; margin-right: 6px; margin-left: 6px;" class="uk-button uk-button-default" href="<?=$dir?>/doc/1">Documentation</a>
				</div>
			</div>
		</div>
	</div>

<div style="margin-top: 50px !important;" class="uk-section">
	<div class="uk-container">
		<h2 class="uk-h1 uk-text-center">Full-stack PHP applications made easy</h2>
		<p class="uk-text-lead uk-text-center">Fastly has all the tools you need to make the Web. Faster.</p>
		<div class="uk-child-width-1-3@m uk-grid-match uk-text-center uk-margin-medium-top" data-uk-grid>
			<div style="text-align: left !important;">
				<div style="padding: 30px 30px; border-radius: 8px; border-color: #e9e9e9;" class="uk-card uk-card-default uk-box-shadow-medium uk-card-hover uk-card-body uk-inline border-radius-large border-xlight">
					<a class="uk-position-cover" href="<?=$dir?>/doc/1"></a>
					<h3 style="margin-top: 0px !important;" class="uk-card-title uk-margin">Getting Started</h3>
					<p>Get started fast with installation and theme setup instructions</p>
					<a style="color: #0070f3;">Documentaion →</a>
				</div>
			</div>
			<div style="text-align: left !important;">
				<div style="padding: 30px 30px; border-radius: 8px; border-color: #e9e9e9;"
					class="uk-card uk-card-default uk-box-shadow-medium uk-card-hover uk-card-body uk-inline border-radius-large border-xlight">
					<a class="uk-position-cover" href="<?=$dir?>/doc/2"></a>
					<h3 style="margin-top: 0px !important;" class="uk-card-title uk-margin">Product Features</h3>
					<p>Lean about all the theme options, features and how to use them</p>
					<a style="color: #0070f3;">Documentaion →</a>
				</div>
			</div>
			<div style="text-align: left !important;">
				<div style="padding: 30px 30px; border-radius: 8px; border-color: #e9e9e9;"
					class="uk-card uk-card-default uk-box-shadow-medium uk-card-hover uk-card-body uk-inline border-radius-large border-xlight">
					<a class="uk-position-cover" href="<?=$dir?>/doc/3"></a>
					<h3 style="margin-top: 0px !important;" class="uk-card-title uk-margin">Customization</h3>
					<p>Get help or tailor the theme to your specific requirements</p>
					<a style="color: #0070f3;">Documentaion →</a>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="uk-section section-featured">
	<div class="uk-container uk-container-small">
		<h2 class="uk-h1 uk-text-center">In-depth Articles</h2>
		<p class="uk-text-center uk-text-lead">The articles about Fastly from the Alek's team</p>
		<ul class="uk-list uk-list-large uk-margin-medium-top">
			<?php  foreach ($data['articles'] as $article) { ?>
				<li><a class='uk-box-shadow-hover-small' href="<?=$dir?>/article/<?=$article['id']?>"><?=$article['title']?></a></li>
			<?php	} ?>
		</ul>
	</div>
</div>

<div class="uk-section section-team">
	<div class="uk-container uk-container-expand">
		<h2 class="uk-h1 uk-text-center">Ready to help</h2>
		<p class="uk-text-lead uk-text-center">Our team is just an email away ready to answer your questions</p>
		<div class="uk-margin-medium-top uk-grid-small uk-flex-center uk-text-center uk-margin-medium-top" data-uk-grid>
			<?php  foreach ($data['users'] as $user) { ?>
				<div>
					<div class="uk-card">
						<img style="width: 86px; height: 86px;" class="uk-border-circle" src="<?=$dir?>/public/<?=$user['img']?>" />
						<h5 class="uk-margin-remove-bottom uk-margin-top"><?=$user['name']?></h5>
						<p class="uk-article-meta uk-margin-remove-bottom uk-margin-small-top"><?=$user['role']?></p>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
</div>

<div class="uk-section uk-text-center">
	<div class="uk-container uk-container-small">
		<div data-uk-scrollspy="cls: uk-animation-slide-bottom-medium; repeat: true">
			<h2 class="uk-h1 uk-margin-bottom">Didn't find an answer?</h2>
			<p class="uk-text-lead uk-text-center">Fastly is getting better every day — don’t miss out on all the action.</p>
			<a class="uk-button uk-button-success uk-button-large uk-margin-medium-top" style="font-size: 16px;" href="<?=$dir?>/contact">Contact Us</a>
		</div>
	</div>
</div>