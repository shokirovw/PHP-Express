<div class="uk-section">
  <div class="uk-container container-xxsmall">
    <h1 class="uk-article-title">Changelog posts</h1>
    <div class="article-content">
    </div>
    <?php foreach ($data['changes'] as $change) { ?>
      <article class="uk-article uk-margin-medium-top">
      <hr class="uk-margin-medium-bottom">
      <div class="uk-position-relative">
        <h2><?=$change['title']?></h2>
        <div class="uk-position-center-left-out uk-position-large uk-visible@m uk-text-small uk-text-muted">
          <time datetime="2019-04-22T00:00:00+00:00"><?=$change['date']?></time>
        </div>
      </div>
      <?php include('objects/'.$change['location']); ?>
    </article>
    <?php } ?>
  </div>
</div>