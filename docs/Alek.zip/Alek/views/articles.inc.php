<div class="uk-section">
	<div class="uk-container uk-container-xsmall">
		<h1 class="uk-article-title uk-text-center">Blog</h1>
		<?php foreach ($data['articles'] as $article) { ?>
			<div
				class="uk-card uk-card-default uk-box-shadow-small uk-box-shadow-hover-medium card-post uk-inline border-radius-medium border-xlight uk-width-1-1 uk-margin">
				<a class="uk-position-cover" href="<?=$dir?>/article/<?=$article['id']?>"></a>
				<div class="uk-card-header">
					<div class="uk-grid-small uk-flex-middle" data-uk-grid>
						<div class="uk-width-expand">
							<h3 class="uk-card-title uk-margin-remove-bottom"><?=$article['title']?></h3>
							<p class="uk-text-meta uk-margin-remove-top"><time datetime="2017-05-25T00:00:00+00:00">
								<?=$article['date']?>
							</time></p>
						</div>
					</div>
				</div>
				<div class="uk-card-body">
					<p><?=$article['description']?></p>
				</div>
				<div class="uk-card-footer">
					<span class="uk-button uk-button-text">Read more →</span>
				</div>
			</div>
		<?php } ?>
	</div>
</div>