<div class="article-content">
      <p>April comes with a whole bunch of updates across our stack, the main focus for this month in regards to what
      was released is around:</p>
      <p>Further improving system, and allowing you to compare your results against wide averages for deflection rates
      Improvements to our tool to give you and your team more control
      And various other new features, updates, and bug fixes along the way.</p>
      <p><span class="uk-label" style="background-color: #3778ff">Added</span></p>
      <ul>
      <li>Some scheduled changelogs, tweets, and slack messages queued up this weekend and were not published on
      time. We fixed the issue and all delayed publications should be out.</li>
      <li>We now prioritize keywords over title and body so customers can more effectively influence search results
      </li>
      <li>Support form in the Assistant is now protected with reCaptcha to reduce spam reinitializeOnUrlChange added
      to the JavaScript API to improve support for pages with turbolinks</li>
      </ul>
      <p><span class="uk-label" style="background-color: #ff4772">Fixed</span></p>
      <ul>
      <li>Fixed an issue with the sync autolinker only interlinking selectively.</li>
      <li>Fixed up an issue with prematurely logging out users</li>
      </ul>
</div>