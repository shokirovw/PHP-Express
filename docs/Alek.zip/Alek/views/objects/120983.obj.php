<div class="article-content">
      <p>February updates across our stack, the main focus for this month in regards to what was released is around:
      </p>
      <p>Migrating all companies to new access control
      Migrating all companies using ticket deflection to the new system
      Further improving system, and allowing you to compare your results against wide averages for deflection rates
      </p>
      <p><span class="uk-label" style="background-color: #3aaa55">Changed</span></p>
      <ul>
      <li>Better support for using applying additional filters to posts_tax_query for categories for custom
      WordPress syncs</li>
      <li>Reporting fine-tuning for speed improvements (up to 60% improvement in latency)</li>
      <li>Search engine upgraded. Bringing with it enhancements and bug fixes.</li>
      <li>Replaced login / registration pre-app screens with a cleaner design</li>
      </ul>
      <p><span class="uk-label" style="background-color: #ff4772">Fixed</span></p>
      <ul>
      <li>Fixed an issue with the sync autolinker only interlinking selectively.</li>
      <li>Fixed up an issue with prematurely logging out users</li>
      </ul>
        <div class="language-html highlighter-rouge">
          <div class="highlight">
<pre class="highlight"><code><span class="nt">&lt;head&gt;</span>
  <span class="nt">&lt;meta</span> <span class="na">name=</span><span class="s">"viewport"</span> <span class="na">content=</span><span class="s">"width=device-width, initial-scale=1"</span><span class="nt">&gt;</span>
  <span class="nt">&lt;link</span> <span class="na">rel=</span><span class="s">"stylesheet"</span> <span class="na">href=</span><span class="s">"/assets/css/main.css"</span><span class="nt">&gt;</span>
  <span class="nt">&lt;link</span> <span class="na">rel=</span><span class="s">"shortcut icon"</span> <span class="na">type=</span><span class="s">"image/png"</span> <span class="na">href=</span><span class="s">"/assets/img/favicon.png"</span> <span class="nt">&gt;</span>
  <span class="nt">&lt;script </span><span class="na">src=</span><span class="s">"/assets/js/main.js"</span><span class="nt">&gt;&lt;/script&gt;</span>
<span class="nt">&lt;/head&gt;</span>
</code></pre>
          </div>
        </div>
</div>