      <div class="uk-width-1-1 uk-width-expand@m">
        <article class="uk-article">
          <h1 class="uk-article-title"><?=$data['title']?></h1>
          <p class="uk-text-lead uk-text-muted"><?=$data['description']?></p>
          <div class="uk-article-meta uk-margin-top uk-margin-medium-bottom uk-flex uk-flex-middle">
            <img class="uk-border-circle avatar" src="<?=$dir?>/public/<?=$data['img']?>"
              alt="Sara Galen">
            <div>
              Written by
              <span><?=$data['name']?></span><br>
              <time datetime="2019-10-05"><?=$data['date']?></time>
            </div>
          </div>
          <?php include('objects/'.$data['location']); ?>
          <hr class="uk-margin-medium">
          <?php if (isset($data['next'])) { ?>
          <div class="uk-margin-large-top paginate-post">
            <div class="uk-child-width-expand@s uk-grid-large" data-uk-grid>
                <div class="uk-text-right"><a class="remove-underline hvr-forward" href="<?=$dir?>/doc/<?=$data['next']['id']?>">Next →</a></div>
            </div>
          </div>
          <?php } ?>
        </article>
      </div>
    </div>
  </div>
</div>