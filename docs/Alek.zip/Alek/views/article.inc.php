<div class="uk-section">
	<div class="uk-container uk-container-xsmall">
		<article class="uk-article">
			<h1 class="uk-article-title"><?=$data['title']?></h1>
			<div class="uk-article-meta uk-margin-top uk-margin-medium-bottom uk-flex uk-flex-middle">
				<img class="uk-border-circle avatar" src="<?=$dir?>/public/<?=$data['img']?>" alt="Tom Farrell">
				<div>
					Written by <?=$data['name']?><br>
					<time datetime="2017-05-25T00:00:00+00:00"><?=$data['date']?></time>
				</div>
			</div>
			<?php include('objects/'.$data['location']); ?>
			<hr class="uk-margin-medium">
			<div class="uk-margin-large-top paginate-post">
				<div class="uk-child-width-expand@s uk-grid-large" data-uk-grid>
					<?php if (isset($data['prev'])) { ?>
						<div class="uk-first-column">
							<h4><?=$data['prev']['name']?></h4>
							<div class="uk-visible@s uk-text-muted uk-text-small">
								<p><?=$data['prev']['desc']?></p>
							</div>
							<div><a class="remove-underline hvr-back" href="<?=$dir?>/article/<?=$data['prev']['id']?>">← Previous</a></div>
						</div>
					<?php } ?>
					<?php if (isset($data['next'])) { ?>
						<div class="uk-first-column">
							<h4><?=$data['next']['name']?></h4>
							<div class="uk-visible@s uk-text-muted uk-text-small">
								<p><?=$data['next']['desc']?></p>
							</div>
							<div class="uk-text-right"><a class="remove-underline hvr-forward" href="<?=$dir?>/article/<?=$data['next']['id']?>">Next →</a></div>
						</div>
					<?php } ?>
				</div>
			</div>
		</article>
	</div>
</div>