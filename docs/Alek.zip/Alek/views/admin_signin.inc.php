<div class="uk-section">
  <div class="uk-container uk-container-xsmall">
    <article class="uk-article">
      <div class="article-content link-primary">
        <form class="uk-form-stacked uk-margin-medium-top" method="POST" action="<?=$dir?>/admin/signin"
          accept-charset="UTF-8">
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="name">Username</label>
            <div class="uk-form-controls">
              <input id="name" class="uk-input uk-form-large uk-border-rounded" name="username" type="text" required="">
            </div>
          </div>
          <div class="uk-margin-medium-bottom">
            <label class="uk-form-label uk-margin-small-bottom" for="_replyto">Password</label>
            <div class="uk-form-controls">
              <input id="_replyto" class="uk-input uk-form-large uk-border-rounded" name="password" type="password" required="">
            </div>
          </div>
          <div>
            <input class="uk-button uk-button-primary uk-button-large uk-width-1-1" type="submit" value="Login">
          </div>
        </form>
      </div>
    </article>
  </div>
</div>