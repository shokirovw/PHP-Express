<?php 

include("express/Router.php");
include("express/databases/mysql.php");

$app = new Router ("");

$app->defLocalConst("name", " | Fastly");
$app->defLocalConst("mail", "muhammadiyor.shakirov@mail.ru");

$database = new MySqlStorage('127.0.0.1', 'root', '', 'fastly');

$app->connectModule($database);


$app->get('/changelog', function ($req, $res) {
      if ($res->isComponentCached('changelog')) {
            $res->renderCached('changelog', ['header' => false, 'footer' => false]);
            return $res->end();
      }

      return $res->next();
}, function ($req, $res, $database) {
      $changelogs = $database->directQuery("SELECT * FROM `changes` WHERE 1");
      $req->set('data', ["changes" => $changelogs]);

      return $res->next();
}, function ($req, $res) {
      $res->enableCapture();

      $res->render('changelog', [
            "title" => "Changelog".$req->getLocalConst("name"),
            "data" => $req->get('data')
      ], true);

      $res->saveCapture('changelog');

      return $res->end();
});



$app->get('/article/:id', function ($req, $res, $database) {
      $article = $database->directQuery('SELECT * FROM `articles`, `users` WHERE articles.id = '.$req->getQueryParams('id').' AND users.id = articles.author_id LIMIT 1');

      $req->set('article_data', $article);

      return $res->next();
}, function ($req, $res) {
      $res->render('article', [
            "title" => "Blog - New Fastly Documentation".$req->getLocalConst("name"),
            "data" => $req->get('article_data')
      ], true);

      return $res->end();
});




$app->get('/articles', function ($req, $res, $database) {
      $articles = $database->directQuery("SELECT id, title, date, description FROM `articles`");
      $req->set('data', ["articles" => $articles]);

      return $res->next();
}, function ($req, $res) {
      $res->render('articles', [
            "title" => "Blog".$req->getLocalConst("name"),
            "data" => $req->get('data')
      ], true);

      return $res->end();
});

$app->get('/doc/:id', function ($req, $res) {
      if ($res->isComponentCached('doc_sidebar')) {
            $res->renderCached('doc_sidebar', ['header' => false, 'footer' => false]);
            return $res->next('route');
      }

      return $res->next();
}, function ($req, $res, $database) {
      $first = $database->directQuery("SELECT docs.id, docs.title, sections.id AS section_id FROM `docs`, `sections` WHERE docs.section_id = sections.id ORDER BY docs.section_id");
      $second = $database->directQuery("SELECT * FROM `sections`");

      $secondd = [];

      for ($i=0; $i < count($second); $i++) { 
            $secondd[$second[$i]["id"] - 1] = $second[$i]["name"];
      }
      
      $third = [];
      
      for ($i = 0; $i < count($first); $i++) {
            $m = $secondd[$first[$i]["section_id"] - 1];

            if (!isset($third[$m])) {
                  $third[$m] = [$first[$i]];
            } else {
                  array_push($third[$m], $first[$i]);
            }
      }

      $req->set('sidebar_data', [
            "tabs" => $third
      ]);

      return $res->next();
}, function ($req, $res) {
      $res->enableCapture();

      $res->render('doc_sidebar', [
            "title" => "Documentation - Get type Requests".$req->getLocalConst('name'),
            "data" => $req->get('sidebar_data')
      ], false);

      $res->saveCapture('doc_sidebar');

      return $res->next('route');
});

$app->get('/doc/:id', function ($req, $res, $database) {
      $doc = $database->directQuery("SELECT * FROM `docs`, `users` WHERE docs.id = ".$req->getQueryParams("id")." AND docs.author_id = users.id");
      $req->set('doc_data', $doc);

      return $res->next();
}, function ($req, $res) {
      $res->render('doc', $req->get('doc_data'), true);

      return $res->end();
});



$app->get('/', function ($req, $res) {
      if ($res->isComponentCached('index')) {
            $res->renderCached('index', ['header' => false, 'footer' => false]);
            return $res->end();
      }

      return $res->next();
}, function ($req, $res, $database) {
      $shortarticles = $database->directQuery("SELECT id, title FROM `articles` LIMIT 3");
      $users = $database->directQuery("SELECT * FROM `users`");
      $req->set('data', ["articles" => $shortarticles, "users" => $users]);

      return $res->next();
}, function ($req, $res) {
      $res->enableCapture();

      $res->render('index', [
            "title" => "Fastly by Alek - The PHP framework",
            "data" => $req->get('data')
      ], true);

      $res->saveCapture('index');

      return $res->end();
});

$app->get('/contact', function ($req, $res) {
      function get_str ($x) {
            $retur = [
                  "error" => "",
                  "message" => ""
            ];

            switch ($x["message"]) {
                  case '200':
                        $retur["error"] = "Too many reports from ".$x["subject"];
                        break;
                  case '100':
                        $retur["message"] = "Succesfully sent. Please wait for reponse at ".$x["subject"];
                        break;
            }

            return $retur;
      } 
      $res->render('contact', [
            "title" => "Contact with us".$req->getLocalConst("name"),
            "data" => (count($req->getQueryString()) > 0 ? get_str($req->getQueryString()) : [])
      ], true);

      return $res->end();
});




$app->post('/receiveContact', function ($req, $res, $database) {
      $formdata = $req->getFormData();

      $count = $database->directQuery("SELECT COUNT(id) as 'count' FROM `reports` WHERE email = '".$formdata['_replyto']."'");


      if (intval($count["count"]) > 2) {
            return $res->redirect('/contact?message=200&subject='.$formdata['_replyto']);
      } else {
            $database->insertQuery("INSERT INTO `reports` (`id`, `name`, `email`, `subject`, `message`, `replied`) VALUES (NULL, '".$formdata['name']."', '".$formdata['_replyto']."', '".$formdata['_subject']."', '".$formdata['message']."', 0)");
            return $res->redirect('/contact?message=100&subject='.$formdata['_replyto']);
      }
});

$app->space("/admin", function ($adminRouter) {
      $adminRouter->post('/signin', function ($req, $res) {
            if ($req->getFormData("username") == "admin" && $req->getFormData("password") == '312213') {
                  $req->setSession("admin", 312213);
                  return $res->redirect('/');
            } else {
                  return $res->next();
            }
      });

      $adminRouter->use(function ($req, $res) {
            $admin_right = $req->getSession("admin");
            if ($admin_right != 312213) {
                  $res->render("admin_signin", null, true);
                  return $res->end();
            } else {
                  return $res->next();
            }
      });

      $adminRouter->get("/", function ($req, $res, $database) {
            $articles = $database->directQuery("SELECT * FROM `reports` WHERE replied = 0");

            if (!isset($articles[0])) {
                  $articles = [$articles];
            }

            $res->render("admin_homepage", [
                  "title" => "Blog".$req->getLocalConst("name"),
                  "data" => [
                        "reports" => $articles
                  ]
            ], true);
      });

      $adminRouter->get('/report/:id', function ($req, $res, $database) {
            $report = $database->directQuery("SELECT * FROM `reports` WHERE id = '".$req->getQueryParams("id")."' LIMIT 1");

            if (count($report) == 0) {
                  return $res->redirect('/');
            } else {
                  $res->render("admin_report", [
                        "title" => "Report ".$req->getLocalConst("name"),
                        "data" => $report
                  ], true);
            }
      });

      $adminRouter->post('/reply/:id', function ($req, $res, $database) {
            $message = $req->getFormData("reply");

            if (!$message || empty($message)) {
                  return $res->redirect('/report'.'/'.$req->getQueryParams("id"));
            }

            if (!is_numeric($req->getQueryParams("id"))) {
                  $res->write("Invalid id");
                  $res->write($message);
                  return $res->end();
            }

            $res = $database->directQuery("SELECT id, email, name FROM `reports` WHERE id = '".$req->getQueryParams("id")."' LIMIT 1");

            if (count($res) == 0) {
                  $res->write("Id doesn't exist");
                  $res->write($message);
                  return $res->end();
            } else {
                  $email = $res["email"];

                  $m = mail($email, 'Support service | Fastly', $res['name'].', thank you for leaving your report in Fastly support service, here we found a solution to your problem. '.$message, 'From: '.$req->getLocalConst("mail"));

                  if ($m) {
                        $database->insertQuery("UPDATE `reports` SET `replied`= 1 WHERE id=".$res["id"]);

                        echo 'Message has been succesfully sent to: '.$email. "<br>";
                        echo "<a href='/'>Go to homepage</a>";
                  } else {
                        $res->write("Internal Server Error");
                        $res->write($message);
                        return $res->end();
                  }
            }
      });
})

?>