<?php 

include("express/Router.php");
include("express/databases/mysql.php");

$app = new Router ("");

$database = new MySqlStorage('127.0.0.1', 'root', '', 'fastly');

$app->connectModule($database);

$database->createMethod('getUserNameByID', function ($db, $id) {
      return $db->directQuery('SELECT * FROM `articles` WHERE id = '.$id.' LIMIT 1');
});

$app->get('/user/:userid', function ($req, $res, $database) {
      $article = $database->directQuery('SELECT * FROM `articles`, `users` WHERE articles.id = 1 AND users.id = articles.author_id LIMIT 1');
      var_dump($article);
      return $res->end();
});

?>